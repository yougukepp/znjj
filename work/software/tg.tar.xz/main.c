#include <htc.h>

#include "tick.h"
#include "led.h"
#include "adc.h"
#include "pwm.h"
#include "nrf905.h"
#include "parse.h"

void error(void)
{
    FlashLed(3);
}

void interrupt system_interrupt()
{
    if(RBIF==1)//无线接收程序
    {
        if(RB5==1)
        {
            Rx();
            ParseFrame();
        }
        RBIF=0;//设置为接收模式
    }

    if(1 == TMR2IF)//T2 interrupt for pwm
    {
        TMR2IF=0;//中断标志位置0
        TRISC2=0;//RC2引脚为输出模式
    }

    if(1 == TMR1IF)//T1 interrupt
    {
        SetSlice(TICK_SLICE);
        TMR1IF = 0;
        IncTicks();
    }
}

void InitSystem(void)
{
    InitNrf905();
    InitAdc();
    InitPwm();
    InitTick(TICK_SLICE);
    InitLed();
}

int main(void)
{
    InitSystem();

    while(1)
    {
        if(1 == GetTicks())
        {
            DoAdc();
            NOP();
        }
        else if(20 == GetTicks())   // PWM 需要每20ms执行一次
        {
            UpdatePwm();
            SetTicks(1);            // 调度切换到DoAdc
        }
        else
        {
            NOP();
        }
    }

    return 0;
}

