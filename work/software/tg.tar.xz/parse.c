#include "parse.h"

static bool IsFrameValid(void)
{
    return (('*' == gRxBuf[0] )
          && ('#' == gRxBuf[15])) ? (true) : (false);
}

static bool IsBuildNetwork(void)
{
    return (('?' == gRxBuf[1]) && ('?' == gRxBuf[2]) && ('?' == gRxBuf[3]))
           ? (true) : (false);
}

static bool IsLightCmd(void)
{
    return (('5' == gRxBuf[1]) && ('5' == gRxBuf[2]) && ('6' == gRxBuf[3])
           && ('2' == gRxBuf[7]) &&( '?' == gRxBuf[8])) ?
           (true) : (false);
}

static void AnswerAddr(void)
{
    gTxBuf[0] = '*';
    gTxBuf[1] = gRxBuf[4];
    gTxBuf[2] = gRxBuf[5];
    gTxBuf[3] = gRxBuf[6];
    gTxBuf[4] = '5';
    gTxBuf[5] = '5';
    gTxBuf[6] = '6';
    gTxBuf[7] = 'k';
    gTxBuf[8] = '$';
    gTxBuf[9] = '$';
    gTxBuf[10] = '$';
    gTxBuf[11] = '$';
    gTxBuf[12] = '$';
    gTxBuf[13] = '$';
    gTxBuf[14] = '$';
    gTxBuf[15] = '#';

    Tx();
}

static void AnswerStatus(u8 c)
{
    gTxBuf[0] = '*';
    gTxBuf[1] = gRxBuf[4];
    gTxBuf[2] = gRxBuf[5];
    gTxBuf[3] = gRxBuf[6];
    gTxBuf[4] = gRxBuf[1];
    gTxBuf[5] = gRxBuf[2];
    gTxBuf[6] = gRxBuf[3];
    gTxBuf[7] = gRxBuf[7];
    gTxBuf[8] = gRxBuf[8];
    gTxBuf[10] = gRxBuf[10];
    gTxBuf[11] = gRxBuf[11];
    gTxBuf[12] = gRxBuf[12];
    gTxBuf[13] = gRxBuf[13];
    gTxBuf[14] = gRxBuf[14];
    gTxBuf[15] = gRxBuf[15];

    switch(gLightThreshold)
    {
        case COMMON_THRESHOLD:
        {
            gTxBuf[9] = COMMON + '0';
            break;
        }
        case WRITING_THRESHOLD:
        {
            gTxBuf[9] = WRITING + '0';
            break;
        }
        case READING_THRESHOLD:
        {
            gTxBuf[9] = READING + '0';
            break;
        }
        case GUEST_THRESHOLD:
        {
            gTxBuf[9] = GUEST + '0';
            break;
        }
        case NEWSPAPER_THRESHOLD:
        {
            gTxBuf[9] = NEWSPAPER + '0';
            break;
        }
        case OFFICE_THRESHOLD:
        {
            gTxBuf[9] = OFFICE + '0';
            break;
        }
        case MEETING_THRESHOLD:
        {
            gTxBuf[9] = MEETING + '0';
            break;
        }
        default:
        {
            gTxBuf[9] = 0;
            break;
        }
    }
     
    Tx();
}

static void ChangeStatus(u8 c)
{
    c = c - '0';
    switch (c)
    {
        case COMMON:
        {
            gLightThreshold = COMMON_THRESHOLD;
            break;
        }
    case WRITING:
        {
            gLightThreshold = WRITING_THRESHOLD;
            break;
        }
    case READING:
        {
            gLightThreshold = READING_THRESHOLD;
            break;
        }
    case GUEST:
        {
            gLightThreshold = GUEST_THRESHOLD;
            break;
        }
    case NEWSPAPER:
        {
            gLightThreshold = NEWSPAPER_THRESHOLD;
            break;
        }
    case OFFICE:
        {
            gLightThreshold = OFFICE_THRESHOLD;
            break;
        }
    case MEETING:
        {
            gLightThreshold = MEETING_THRESHOLD;
            break;
        }
    default:
        {
            break;
        }
    }
}

static void Parse(void)
{
    u8 c = gRxBuf[9];
    if('?' == c)
    {
        // 因为交互未调通
        // 暂时在网关端采用控制后 存储的方式
        // 而非 交互方式
        AnswerStatus(c);
    }
    else
    {
        ChangeStatus(c);
    }
    return;
}

void ParseFrame()
{
    if(!IsFrameValid())
    {
        return;
    }
    else if(IsBuildNetwork())
    {
        AnswerAddr();
    }
    else if(IsLightCmd())
    {
        Parse();
    }
    else
    {
        NOP();
    }
}

