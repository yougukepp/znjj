#include "pwm.h"
#include "adc.h"
#include "led.h"

unsigned int gLightThreshold=0;//根据环境设定的阈值

void InitPwm()
{
    OSCCON=0x45;   //配置系统内部时钟为1MHz

    TRISC2=1;      //RC1和RC2引脚为输入模式
    PR2=0x39;      //设置PWM周期为270Hz
    CCPR1L=46;   //
    CCP1CON=0x0C;  //配置为PWM模式
    PEIE=1;  //使能外设中断
    TMR2IE=1;        //定时器2中断打开
    TMR2IF=0;        //中断标志位置0
    T2CON=0x03;   //16分频
    TMR2ON=1;  //启动定时器2
    gLightThreshold=600;
}

unsigned int UpdatePwm()
{
    if((gLight+PWM_SHAKE) < gLightThreshold)
    {
        OpenLed();
        CCPR1L++;
        if(CCPR1L>55)
        {
            CCPR1L--;
        }
    }
    else if((gLight-PWM_SHAKE) > gLightThreshold )
    {
        CloseLed();
        CCPR1L--;
        if(CCPR1L<2)
        {
            CCPR1L++;
        }
    }
    else
    {
        NOP();
    }
    return 0;
}


