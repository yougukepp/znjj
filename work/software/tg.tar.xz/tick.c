#include "tick.h"

static unsigned char gTicks;

void StartTick(void)
{
    TMR1ON = 1;
}

void PauseTick(void)
{
    TMR1ON = 0;
}

void SetSlice(int slice)
{
    long initValue = 65535 - TICK_NUMS_1MS*slice;
    TMR1H = initValue >> 8;
    TMR1L = (unsigned char)initValue;
}

void SetTicks(int ticks)
{
    gTicks = ticks;
}

int GetTicks(void)
{
    return gTicks;
}

void IncTicks(void)
{
    gTicks++;
}

void InitTick(int slice)
{
    SetSlice(slice);
    T1CON = 0;
    GIE=1;
    TMR1IE = 1;
    SetTicks(1);
    StartTick();
}


