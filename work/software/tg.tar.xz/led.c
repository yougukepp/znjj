#include "led.h"

void InitLed(void)
{
    ANSELH &= 0x2F;             //AN12 Digit Port
    TRISB0 = 0;
    CloseLed();
}

void OpenLed(void)
{
    RB0 = 0;
}

void CloseLed(void)
{
    RB0 = 1;
}

void FlashLed(int times)
{
    int i = 0;
    CloseLed();
    for(i=0; i<times; i++)
    {
        CloseLed();
        __delay_ms(100);
        OpenLed();
        __delay_ms(100);
    }
    CloseLed();
}


