#include "nrf905.h"

void NRF905GPIO_Configuration(void)
{
    ANS13=0; //将无线模块的RB5-DR设置为数字端口

    //PSTRCON=0;
    TRISC1=0;//CSN,SPI使能
    TRISC0=0;//SCK,SPI时钟
    TRISC3=0;//SPI接口MOSI,单片机作为输出端口，无线模块作为输入

    TRISC5=0;// 芯片上电
    TRISC6=0; //使能芯片发送或接收，单片机作为输出端口，无线模块作为数字输入
    TRISC7=0;//TX,RX模式，单片机作为输出端口，无线模块作为数字输入
    TRISD0=1;//SPI接口MISO，单片机作为输入，无线模块作为输出
    TRISD2=1;//AM，单片机输入
    TRISD3=1;//CD，单片机输入
    TRISB5=1;//DR，单片机输入
}

//==========================32字节发送数据收发缓冲区============================
unsigned char gTxBuf[FRAME_LENGTH];
unsigned char gRxBuf[FRAME_LENGTH];

static u8 gTxAddr[4]={0xcc,0xcc,0xcc,0xcc};
static u8 gDataBuf;

//==========================NRF905：10寄存器配置================================
unsigned char  RFConf[11]=
{
    WC,                                //SPI写操作命令
    0x4c,                              //CH_NO,配置频段在430MHZ
    0x0C,                              //输出功率为10db,不重发，节电为正常模式
    0x44,                              //地址宽度设置，为4字节
    0x10,0x10,                         //接收发送有效数据长度为32字节
    0xCC,0xCC,0xCC,0xCC,               //接收地址
    0x58,                              //CRC充许，8位CRC校验，外部时钟信号不使能，16M晶振
};

//===========================初始化nRF905=======================================
void nRF905_IO_set(void)
{
    CSN_1;                            // Spi     disable
    SCK_0;                          // Spi clock line init low
    PWR_1;                     // nRF905 power on
    TRX_CE_0;                // Set nRF905 in standby mode
    TXEN_0;                    // set radio in Rx mode
}

//=========================NRF905 SPI读函数（IO模拟SPI时序）==================
unsigned char SpiRead(void)
{
    unsigned char i;
    unsigned char m;
    for (i=0;i<8;i++)
    {
            gDataBuf=gDataBuf<<1;
        SCK_1;
        m=MISO;
        if (m==1)    //读取最高位，保存至最末尾，通过左移位完成整个字节
        {
            gDataBuf|=0x01;
        }
        else
        {
            gDataBuf&=~(0x01);
        }
        SCK_0;
     }
     return gDataBuf;
}

//=========================NRF905 SPI读写函数（IO模拟SPI时序）==================
void SpiWrite(unsigned char send)
{
    unsigned char i;
    gDataBuf=send;
    for (i=0;i<8;i++)
    {
    if (((gDataBuf&0x80) != 0))    //总是发送最高位
        {
        MOSI_1;
     }
    else
     {
        MOSI_0;
     }
    SCK_1;
    gDataBuf=gDataBuf<<1;
    SCK_0;
    }
}

//==================================初始化NRF905================================
void Config905(void)
{
    u8 i;
    CSN_0;                        // Spi enable for write a spi command
    for (i=0;i<11;i++)    // Write configration words  写放配置字
    {
       SpiWrite(RFConf[i]);
    }
    CSN_1;                    //关闭SPI
}

//=========================NRF905装载地址+数据打包+数据发送=====================
void TxPacket(void)
{
    u8 i;
    CSN_0;
    SpiWrite(WTP);                // 待发数据装载命令
    for (i=0;i<FRAME_LENGTH;i++)
    {
      SpiWrite(gTxBuf[i]);
    }
    CSN_1;                                  // 关闭SPI
    __delay_us(10);
    CSN_0;                    // 打开SPI
    SpiWrite(WTA);                // 写入地址要和接收方地址一样
    for (i=0;i<4;i++)            // 4字节地址
    {
      SpiWrite(gTxAddr[i]);
    }
    CSN_1;                    //关闭SPI
    TRX_CE_1;                    // Set TRX_CE high,start Tx data transmission
    __delay_us(10);        // while (DR!=1);
    TRX_CE_0;                    // Set TRX_CE low
}

//==================================发送模式初始化-=============================
void SetTxMode(void)
{
    TRX_CE_0;
    TXEN_1;
    __delay_us(700);                     // Delay for mode change(>=650us)
}

//==================================数据发送===================================
void Tx(void)
{
    SetTxMode();
    __delay_us(10);
    TxPacket();
}

//=========DR检测,当 收到数据后DR置1，当把数据读出来后DR清0=====================
unsigned char CheckDR(void)                   //检查是否有新数据传入 Data Ready
{
    unsigned char n;
    n=DR;
    n=n&&0x01;
    if (n==1)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
//==============================================================================
void SetRxMode(void)
{
    TXEN_0;
    TRX_CE_1;
    __delay_us(10);         // delay for mode change(>=650us)
}
//=================================数据接收=====================================
void RxPacket(void)
{
    char i;
    __delay_us(10);
    TRX_CE_0;
    CSN_0;                         // SPI使能（Spi enable for write a spi command）
    __delay_us(10);
    SpiWrite(RRP);               // 读SPI数据命令（Read payload command）
    for (i = 0 ;i < FRAME_LENGTH ;i++)
    {
      gRxBuf[i]=SpiRead();         // Read data and save to buffer
    }
    CSN_1;
    __delay_us(10);
    TRX_CE_1;
}

//==========================NRF905数据接收流程================================
void  Rx(void)
{
    SetRxMode();            // Set nRF905 in Rx mode
    __delay_us(10);
    RxPacket();               // Recive data by nRF905
}

//----------------------------设置中断接收-------------------------------------//
void DR_EXTI()
{
    RBIE=1;//允许PORTB电平变化中断
    IOCB5=1;//允许PORTB0电平中断
    RBIF=0;//标志位清零
    GIE=1;//全局中断开
}

//---------------------------NRF905总初始化函数-------------------------------//
void InitNrf905(void)
{
    NRF905GPIO_Configuration();
    nRF905_IO_set();
    Config905();
    DR_EXTI();
    SetRxMode();
}

