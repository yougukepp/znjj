#ifndef __TICK_H__
#define __TICK_H__

#include <htc.h>
#include "config.h"

#define TICK_SOURCE (_XTAL_FREQ / 4)
#define TICK_NUMS_1MS (TICK_SOURCE/1000)

void InitTick(int slice); //ÿ��slice ms����һ���ж�0 <= slice < 32 (32.7675)ms
void StartTick(void);
void PauseTick(void);
void SetSlice(int slice);
void SetTicks(int ticks);
int GetTicks(void);
void IncTicks(void);

#endif
