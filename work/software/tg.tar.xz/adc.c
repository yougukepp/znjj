#include"adc.h"

unsigned int gLight;
/*AD初始化*/
void InitAdc()
{
    TRISA0=1;/*设置模拟信号引脚为输入状态,端口为PORTA0*/
    ADCON0=0x01;/*设置时钟为 FOSC/2，输入通道为AN0,GO/DONE设置为0，ADON使能为1*/
    ADCON1=0X80;/*格式为右对齐，参考电压为VSS,VDD*/
}

/*AD数据采集*/
unsigned int DoAdc()
{    
    static unsigned int sum = 0;
    static u8 i = 0;
    static unsigned int lightBuf[ADC_POINT_NUMS];
    
    unsigned int light = 0;
    
    ADCON0=ADCON0|0x02;//启动AD
    while(ADCON0&0x02);//等待AD采样结束    

    light = (ADRESH<<8) + ADRESL;
    
    lightBuf[i]=light;
    sum += lightBuf[i];
    i++;
    if(i==ADC_POINT_NUMS)//取AD采样ADC_POINT_NUMS次的平均值存放在light_aver[2]中
    {
            
        gLight=sum/ADC_POINT_NUMS;
        sum=0;
        i=0;
    }
    return 0;    
}

