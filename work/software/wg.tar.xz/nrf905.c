#include "nrf905.h"

void NRF905GPIO_Configuration(void)
{ 
    ANSD4=0;
    ANSD5=0;
    ANSD6=0;
    ANSD7=0;
    ANSB2=0;
    ANSB3=0;
    ANSB1=0;
    ANSB4=0;
    ANSB0=0;
    ANSB5=0;

    TRISC5=0;
    TRISD5=0; 
    TRISD4=0;
    TRISD6=1;
    TRISB1=1;
    TRISB0=1;
    TRISB3=1;
    TRISB2=0;	
    TRISB5=0;
    TRISB4=0;
}
//----------------------------设置中断接收-------------------------------------//
void DR_EXTI()
{
    IOCIE=1;
    IOCBP0=1;//允许PORTB0上升沿中断
    IOCBF0=0;//标志位清零
    GIE=1;
}

//==========================16字节发送数据收发缓冲区============================
unsigned u8 gBufNrf905TxUartRx[FRAME_LENGTH];
unsigned u8 gBufNrf905RxUartTx[FRAME_LENGTH];
static u8 gTxAddr[4]={0xcc,0xcc,0xcc,0xcc};
static u8 gDataBuf;

//==========================NRF905：10寄存器配置================================
unsigned char  RFConf[11]=
{
    WC,                                 //SPI写操作命令
    0x4c,                               //CH_NO,配置频段在430MHZ
    0x0C,                               //输出功率为10db,不重发，节电为正常模式
    0x44,                               //地址宽度设置，为4字节
    0x10,0x10,                        //接收发送有效数据长度为32字节
    0xCC,0xCC,0xCC,0xCC,         //接收地址
    0x58,                               //CRC充许，8位CRC校验，外部时钟信号不使能，16M晶振
};

//===========================初始化nRF905=======================================
void nRF905_IO_set(void)
{   
    CSN_1;                                // Spi 	disable
    SCK_0;                                // Spi clock line init low
    PWR_1;                               // nRF905 power on
    TRX_CE_0;                           // Set nRF905 in standby mode
    TXEN_0;                              // set radio in Rx mode
}

//=========================NRF905 SPI读函数（IO模拟SPI时序）==================
unsigned char SpiRead(void)
{
    u8 i;
    u8 m;
    for (i=0;i<8;i++)
    {
        gDataBuf=gDataBuf<<1;
        SCK_1;
        m=MISO;
        if (m==1)	//读取最高位，保存至最末尾，通过左移位完成整个字节
        {
            gDataBuf|=0x01;
        }
        else
        {
            gDataBuf&=~(0x01);
        }
        SCK_0;
    }
    return gDataBuf;
}

//=========================NRF905 SPI读写函数（IO模拟SPI时序）==================
void SpiWrite(unsigned char send)
{
    u8 i;
    gDataBuf=send;
    
    for (i=0;i<8;i++)
    {
        if (((gDataBuf&0x80) != 0))	//总是发送最高位
        {
            MOSI_1;
        }
        else
        {
            MOSI_0;
        }
        SCK_1;
        gDataBuf=gDataBuf<<1;
        SCK_0;
    }
}

//==================================初始化NRF905================================
void Config905(void)
{
    u8 i;
    CSN_0;						// Spi enable for write a spi command
    for (i=0;i<11;i++)	// Write configration words  写放配置字
    {
        SpiWrite(RFConf[i]);
    }
    CSN_1;					//关闭SPI
}

//=========================NRF905装载地址+数据打包+数据发送=====================
void TxPacket(void)
{
    u8 i;
    CSN_0;
    SpiWrite(WTP);				// 待发数据装载命令
    for (i=0;i<FRAME_LENGTH;i++)
    {
        SpiWrite(gBufNrf905TxUartRx[i]);
    }
    CSN_1;                                  // 关闭SPI
    __delay_us(10);
    CSN_0;					// 打开SPI
    SpiWrite(WTA);				// 写入地址要和接收方地址一样
    for (i=0;i<4;i++)			// 4字节地址
    {
        SpiWrite(gTxAddr[i]);
    }
    CSN_1;					//关闭SPI
    TRX_CE_1;					// Set TRX_CE high,start Tx data transmission
    __delay_us(10);		// while (DR!=1);
    TRX_CE_0;					// Set TRX_CE low
}

//==================================发送模式初始化-=============================
void SetTxMode(void)
{
    TRX_CE_0;
    TXEN_1;
    __delay_us(700); 					// Delay for mode change(>=650us)
}

//==============================================================================
void SetRxMode(void)
{
    TXEN_0;
    TRX_CE_1;
    __delay_us(10); 		// delay for mode change(>=650us)
}

//==================================数据发送===================================
void TxFrameByNrf905(void)
{
    SetTxMode();
    __delay_us(10);
    TxPacket();
}

//=================================数据接收=====================================
void RxPacket(void)						
{
    u8 i;
    __delay_us(10);
    TRX_CE_0;
    CSN_0;		                 // SPI使能（Spi enable for write a spi command）
    __delay_us(10);
    SpiWrite(RRP);               // 读SPI数据命令（Read payload command）
    for (i = 0 ;i < FRAME_LENGTH ;i++)
    {  
        gBufNrf905RxUartTx[i]=SpiRead();		 // Read data and save to buffer    
    }
    CSN_1;
    __delay_us(10);
    TRX_CE_1;							
}

//==========================NRF905数据接收流程================================
void  RxFrameByNrf905(void)
{
    SetRxMode();			// Set nRF905 in Rx mode
    __delay_us(10);
    RxPacket();		       // Recive data by nRF905
}

//---------------------------NRF905总初始化函数-------------------------------//
void InitNrf905(void)
{
    NRF905GPIO_Configuration();
    nRF905_IO_set();
    Config905();
    DR_EXTI();
    SetRxMode();
}


