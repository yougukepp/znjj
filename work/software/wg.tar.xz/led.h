#ifndef    __LED_H__
#define    __LED_H__

#include <htc.h>
#include "config.h"

void InitLed(void);
void OpenLed(void);
void CloseLed(void);
void FlashLed(int times);

#endif

