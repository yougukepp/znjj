#include <htc.h>

#include "nrf905.h"
#include "uart.h"
#include "led.h"

static u8 gTaskFlag;
static u8 gUartRxChar;

#define TASK_NO  (0)
#define TASK_A2N (1)
#define TASK_N2A (2)

void interrupt SystemInterrupt(void)     
{
    /* nf905 接收 */
    if(1 == IOCBF0) 
    {
        IOCBF0 = 0;
        RxFrameByNrf905();
        /* TODO:找原因 无效帧 */
        if('*' == gBufNrf905RxUartTx[0])
        {
            gTaskFlag = TASK_N2A;
        }
    }

    /* nf905 发送 */
    if(RCIF==1)
    {
        gUartRxChar = RCREG;
        gTaskFlag = TASK_A2N;
        RCIF=0; //No Use, read only ,exit Int should read RCREG        
    }
}

static void InitSystem(void)
{
    u8 i = 0;
    InitUart();
    InitNrf905();
    InitLed();    
    FlashLed(3);    
    gTaskFlag = TASK_NO;
}

static void TaskA2N(void)
{
    static u8 i = 0;
    gBufNrf905TxUartRx[i++] = gUartRxChar;
    if(FRAME_LENGTH == i)              //获得一帧数据
    {
        TxFrameByNrf905();
        i = 0;
     }
    gTaskFlag = TASK_NO;
}
 
static void TaskN2A(void)
{
    TxFrameByUart();

    gTaskFlag = TASK_NO;
}

int main(void)  
{
    InitSystem();
    
    while(true)
    {
        switch(gTaskFlag)
        {
            case TASK_A2N:
            {
                TaskA2N();
                break;
            }
            case TASK_N2A:
            {
                TaskN2A();
                break;
            }
            case TASK_NO:
            {
                // No Task
                break;
            }
            default:
            {
                // ERROR
                break;
            }    
        }
    }
}

