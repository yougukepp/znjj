#ifndef   _uart_H_
#define   _uart_H_

#include <htc.h>
#include "config.h"
#include "nrf905.h"

extern void InitUart(void);

extern void TxFrameByUart(void);

#endif 
