#include"uart.h"

void InitUart(void)
{
    TRISC6=0;
    TRISC7=1;
    SPEN=1;
    
    SYNC=0;	
    BRGH=0;
    BRG16=0;
    SPBRG=12;
    
    TXEN=1;
    CREN=1;
    RCIE=1;
    GIE=1;
    PEIE=1;
}

static void TxCharByUart(u8 m)
{
    while(TRMT!=1);
    TXREG=m;

   __delay_ms(20);      // 等待串口发送完数据 此处用于9600通过
}

void TxFrameByUart()
{
    u8 i =0;
    for(i=0; i< FRAME_LENGTH; i++)
    {
        TxCharByUart(gBufNrf905RxUartTx[i]);
    }
    TxCharByUart('\n');    // arm tty in stardand mode, read() need '\n'
}


