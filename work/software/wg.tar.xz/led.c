#include "led.h"

void InitLed(void)
{
    TRISC = TRISC & 0xF8;
    CloseLed();
}

void OpenLed(void)
{
    PORTC = 0x00;
}

void CloseLed(void)
{
    PORTC = 0x07;
}

void FlashLed(int times)
{
    int i = 0;
    CloseLed();
    for(i=0; i<times; i++)
    {
        CloseLed();
        __delay_ms(100);
        OpenLed();
        __delay_ms(100);
    }
    CloseLed();
}


