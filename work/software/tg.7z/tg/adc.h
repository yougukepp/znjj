#ifndef    __ADC_H__    
#define    __ADC_H__

#include <htc.h>
#include "config.h"

unsigned int gLight;

void InitAdc(void);
unsigned int DoAdc(void);

#endif
