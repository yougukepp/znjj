#ifndef __PWM_H__
#define __PWM_H__

#include <htc.h>
#include "config.h"
#include "adc.h"

extern unsigned int gLightThreshold;
void InitPwm();
unsigned int UpdatePwm();

#endif
