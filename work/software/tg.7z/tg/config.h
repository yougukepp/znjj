#ifndef __CONFIG_H__
#define __CONFIG_H__

#ifndef false
#define false (0)
#endif

#ifndef true
#define true (~false)
#endif

//类型定义
typedef unsigned char u8;
typedef u8 bool;

// OSC 8M
#define _XTAL_FREQ              (8000000)

//Tick Slice 1ms
#define TICK_SLICE              (1)

//用户避免PWM输出抖动
#define PWM_SHAKE               (5)

//ADC采样后多点平均的 点数
#define ADC_POINT_NUMS          (40)

//协议帧长
#define  FRAME_LENGTH           (16)

//Nrf905 接口
#define  TXEN_1                 (RC7=1)
#define  TXEN_0                 (RC7=0)
#define  TRX_CE_1               (RC6=1)
#define  TRX_CE_0               (RC6=0)
#define  PWR_1                  (RC5=1)
#define  PWR_0                  (RC5=0)
#define  CD                     (RD3)
#define  AM                     (RD2)
#define  DR                     (RB5)
#define  MISO                   (RD0)
#define  MOSI_1                 (RC3=1)
#define  MOSI_0                 (RC3=0)
#define  SCK_1                  (RC0=1)
#define  SCK_0                  (RC0=0)
#define  CSN_1                  (RC1=1)
#define  CSN_0                  (RC1=0)

//===========================NRF905:SPI指令=====================================
#define WC                      (0x00)
#define RC                      (0x10)
#define WTP                     (0x20)
#define RTP                     (0x21)
#define WTA                     (0x22)
#define RTA                     (0x23)
#define RRP                     (0x24)

//==================== 灯光模式 ===================
#define COMMON                  (1)
#define WRITING                 (2)
#define READING                 (3)
#define GUEST                   (4)
#define NEWSPAPER               (5)
#define OFFICE                  (6)
#define MEETING                 (7)

#define COMMON_THRESHOLD        (300)
#define WRITING_THRESHOLD       (601)
#define READING_THRESHOLD       (602)
#define GUEST_THRESHOLD         (1000)
#define NEWSPAPER_THRESHOLD     (650)
#define OFFICE_THRESHOLD        (1001)
#define MEETING_THRESHOLD       (1002)

#endif

