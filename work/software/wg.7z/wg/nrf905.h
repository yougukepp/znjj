#ifndef __NRF905_H
#define __NRF905_H

#include <htc.h>
#include "config.h"

//===========================NRF905:SPIָ��=====================================
#define WC              (0x00)
#define RC              (0x10)
#define WTP             (0x20)
#define RTP             (0x21)
#define WTA             (0x22)
#define RTA             (0x23)
#define RRP             (0x24)

extern u8 gBufNrf905TxUartRx[];		  //�����͵�����
extern u8 gBufNrf905RxUartTx[];		  //���յ�������

extern void InitNrf905(void);
extern void TxFrameByNrf905(void);
extern void RxFrameByNrf905(void);
#endif

