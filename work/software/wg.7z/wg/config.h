#ifndef __CONFIG_H__
#define __CONFIG_H__

#ifndef false
#define false (0)
#endif

#ifndef true
#define true (~false)
#endif

//���Ͷ���
typedef unsigned char    u8;

// OSC 8M
#define _XTAL_FREQ      (8000000)

//Tick Slice 1ms
#define TICK_SLICE      (1)

//Э��֡��
#define FRAME_LENGTH   (16)

//SPI��������
#define  TXEN_1     RC5=1 
#define  TXEN_0     RC5=0 
#define  TRX_CE_1   RD5=1  
#define  TRX_CE_0   RD5=0
#define  PWR_1      RD4=1  
#define  PWR_0      RD4=0 
#define  CD         RD6
#define  AM         RB1
#define  DR         RB0
#define  MISO       RB3
#define  MOSI_1     RB2=1  
#define  MOSI_0     RB2=0
#define  SCK_1      RB5=1 
#define  SCK_0      RB5=0
#define  CSN_1      RB4=1 
#define  CSN_0      RB4=0

#endif
